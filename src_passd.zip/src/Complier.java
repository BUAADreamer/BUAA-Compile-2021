import java.io.*;

public class Complier {
    public static void main(String[] argv) throws IOException {
        LexicalAnalysis lexicalAnalysis = new LexicalAnalysis();
    }
}
